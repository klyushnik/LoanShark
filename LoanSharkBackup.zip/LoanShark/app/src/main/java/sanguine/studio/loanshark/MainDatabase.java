package sanguine.studio.loanshark;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;


@Database(entities = {TablePerson.class, TablePhoneNumber.class, TableMainRecord.class, TableNonMonetaryItems.class, TableHistory.class}, version = 1)
public abstract class MainDatabase extends RoomDatabase {

    public abstract PersonDao personDao();

}
