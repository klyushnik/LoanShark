package sanguine.studio.loanshark;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.nightonke.blurlockview.Directions.HideType;
import com.nightonke.blurlockview.Directions.ShowType;
import com.nightonke.blurlockview.Eases.EaseType;
import com.nightonke.blurlockview.Password;

public class DashboardActivity extends Activity implements View.OnClickListener {

    //com.nightonke.blurlockview.BlurLockView blurLockView;
    boolean hasPassword = false;
    String correctPassword;
    SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dash_board);
        Button borrowersButton, creditorsButton, historyButton, settingsButton, importExportButton, contactsButton;

        LinearLayout rootLayout = findViewById(R.id.dashboardRootLinearLayout); //this needs to be first so that lockscreen can find it
        rootLayout.setPadding(0,Util.GetStatusBarHeight(this),0,0); //set padding so that logo is moved down a bit

        preferences = getSharedPreferences("appSettings", Context.MODE_PRIVATE);

        resetPasswordInfo();

        /*blurLockView = findViewById(R.id.blurlockview);
        blurLockView.setBlurredView(rootLayout);
        blurLockView.setType(Password.NUMBER, true);
        blurLockView.setCorrectPassword(correctPassword);
        blurLockView.setOverlayColor(Color.argb(180,0,0,0));
        blurLockView.setLeftButton("");
        blurLockView.setRightButton(this.getString(R.string.button_backspace));
        blurLockView.setOnPasswordInputListener(this);
        if(!hasPassword)
            blurLockView.setVisibility(View.GONE);
        else
            blurLockView.setVisibility(View.VISIBLE);*/

        borrowersButton = findViewById(R.id.borrowersButton);
        borrowersButton.setOnClickListener(this);
        creditorsButton = findViewById(R.id.creditorsButton);
        creditorsButton.setOnClickListener(this);
        historyButton = findViewById(R.id.historyButton);
        historyButton.setOnClickListener(this);
        settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(this);
        importExportButton = findViewById(R.id.manualButton);
        importExportButton.setOnClickListener(this);
        contactsButton = findViewById(R.id.contactsButton);
        contactsButton.setOnClickListener(this);


    }

    @Override
    public void onClick(View v) {    //button onCLick
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("id", v.getId());
        startActivityForResult(intent, 1);
    }

    void resetPasswordInfo(){
        hasPassword = preferences.getBoolean("hasPassword", false);
        correctPassword = preferences.getString("password", "");
        if(correctPassword.isEmpty()){
            hasPassword = false;
            Log.e("password", "password is empty");
        }else{
            try{
                correctPassword = AESUtils.decrypt(correctPassword);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
    //lockscreen listeners

}
